//---------------------------------------------------------------------------

#ifndef PwdFormUnitH
#define PwdFormUnitH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <FireDAC.Comp.Client.hpp>
#include <FireDAC.Comp.DataSet.hpp>
#include <FireDAC.DApt.hpp>
#include <FireDAC.DApt.Intf.hpp>
#include <FireDAC.DatS.hpp>
#include <FireDAC.Phys.Intf.hpp>
#include <FireDAC.Stan.Async.hpp>
#include <FireDAC.Stan.Error.hpp>
#include <FireDAC.Stan.Intf.hpp>
#include <FireDAC.Stan.Option.hpp>
#include <FireDAC.Stan.Param.hpp>
//---------------------------------------------------------------------------
class TPwdForm : public TForm
{
__published:	// IDE-managed Components
	TButton *CancelButton;
	TButton *OKButton;
	TEdit *LoginEdit;
	TEdit *PwdEdit;
	TLabel *Label1;
	TLabel *Label2;
	TFDQuery *FDQuery;
	TDataSource *DataSource;
	void __fastcall OKButtonClick(TObject *Sender);
	void __fastcall CancelButtonClick(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall LoginEditKeyPress(TObject *Sender, System::WideChar &Key);
	void __fastcall PwdEditKeyPress(TObject *Sender, System::WideChar &Key);
private:	// User declarations
public:		// User declarations
	__fastcall TPwdForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPwdForm *PwdForm;
//---------------------------------------------------------------------------
#endif
