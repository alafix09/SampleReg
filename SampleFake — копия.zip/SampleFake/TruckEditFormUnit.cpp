//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DtModule.h"
#include "TruckEditFormUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTruckEditForm *TruckEditForm;
//---------------------------------------------------------------------------
__fastcall TTruckEditForm::TTruckEditForm(TComponent* Owner)
	: TForm(Owner)
{
	if (FDQuery->Active)
		FDQuery->Close();
	FDQueryMaterial->Open();
	id = -1;
//	setId(-1);
}
//---------------------------------------------------------------------------


bool TTruckEditForm::setId(int id)
{
	if (FDQuery->Active)
		FDQuery->Close();

	if (id >= 0)
	{
		FDQuery->ParamByName("tid")->Value = id;
	}

	FDQuery->Open();

	if (id < 0)
	{
		FDQuery->Append();
		FDQuery->FieldByName("TID")->AsInteger = id;
		FDQuery->FieldByName("User")->NewValue = "user";
		FDQuery->FieldByName("CT")->NewValue = Now();
		FDQuery->FieldByName("TS")->NewValue = Now();
		FDQuery->FieldByName("LPR")->NewValue = 2;
		FDQuery->FieldByName("MID")->NewValue = 1;
		FDQuery->FieldByName("State")->NewValue = 2;
		initCaption = "�������� (�����)";
		EditLPN->Enabled = true;
		CBMat->Enabled = true;
		setChanged(true);
	}
	else
	{
		initCaption = String("�������� (") + id + ")";
		EditLPN->Enabled = false;
		CBMat->Enabled = false;
		setChanged(false);
	}

	((TNumericField*)EditGlyuten->Field)->DisplayFormat = "#.00";
	EditGlyuten->Field->Alignment = taRightJustify;
	((TNumericField*)EditHumidity->Field)->DisplayFormat = "#.00";
	((TNumericField*)EditNature->Field)->DisplayFormat = "#.00";

	return true;
}

void __fastcall TTruckEditForm::OKButtonClick(TObject *Sender)
{
	if (FDQuery->FieldByName("TID")->AsInteger < 0)
	{
		int newId;

		FDQueryId->Open();
		newId = FDQueryId->FieldByName("vParam")->AsInteger;
		FDQueryId->Close();

		FDCommandId->ParamByName("curId")->AsInteger = newId;
		FDCommandId->Execute();
		FDQuery->FieldByName("TID")->AsInteger = newId;
		FDQuery->FieldByName("CT")->NewValue = Now();
	}

	FDQuery->FieldByName("TS")->NewValue = Now();
	setChanged(false);
	FDQuery->ApplyUpdates(-1);
	ModalResult = mrOk;
//	Close();
}
//---------------------------------------------------------------------------
void __fastcall TTruckEditForm::CancelButtonClick(TObject *Sender)
{
//	FDQuery->CancelUpdates();
	ModalResult = mrCancel;
}
//---------------------------------------------------------------------------

void TTruckEditForm::setChanged(bool aChanged)
{
	changed = aChanged;
	if (changed)
	{
		Caption = "*" + initCaption;
	}
	else
	{
		Caption = initCaption;
	}
}






void __fastcall TTruckEditForm::FDQueryAfterEdit(TDataSet *DataSet)
{
	setChanged(true);
}
//---------------------------------------------------------------------------

void __fastcall TTruckEditForm::FDQueryAfterApplyUpdates(TFDDataSet *DataSet, int AErrors)

{
	setChanged(false);
}
//---------------------------------------------------------------------------

void __fastcall TTruckEditForm::FormCloseQuery(TObject *Sender, bool &CanClose)
{
	if (isChanged())
	{
		if (MessageDlg("������ ��������. �� ������������� ������ �����?", mtConfirmation, TMsgDlgButtons() << mbYes << mbNo,0) == mrYes)
		{
			setChanged(false);
			FDQuery->CancelUpdates();
			CanClose = true;
		}
		else
		{
			CanClose = false;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TTruckEditForm::MemoDescriptKeyPress(TObject *Sender, System::WideChar &Key)

{
	if (Key == 27)
	{
		ModalResult = mrCancel;
		Key = 0;
	}
}
//---------------------------------------------------------------------------

