//---------------------------------------------------------------------------

#ifndef TrucksFormUnitH
#define TrucksFormUnitH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <FireDAC.Comp.Client.hpp>
#include <FireDAC.Comp.DataSet.hpp>
#include <FireDAC.DApt.Intf.hpp>
#include <FireDAC.DatS.hpp>
#include <FireDAC.Phys.Intf.hpp>
#include <FireDAC.Stan.Error.hpp>
#include <FireDAC.Stan.Intf.hpp>
#include <FireDAC.Stan.Option.hpp>
#include <FireDAC.Stan.Param.hpp>
#include <FireDAC.DApt.hpp>
#include <FireDAC.Stan.Async.hpp>
#include <Datasnap.DBClient.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
class TTrucksForm : public TForm
{
__published:	// IDE-managed Components
	TFDQuery *FDQuery1;
	TDataSource *DataSource1;
	TDBGrid *DBGrid1;
	TTimer *ClickTimer1;
	TDateTimePicker *FromDateTimePicker;
	TDateTimePicker *ByDateTimePicker;
	TLabel *Label1;
	TLabel *Label2;
	TDBGrid *DBGrid2;
	TFDQuery *FDQuery2;
	TDataSource *DataSource2;
	TStatusBar *StatusBar1;
	TTimer *ClickTimer2;
	TButton *Button1;
	TTimer *RefreshTimer;
	void __fastcall FDQuery1AfterPost(TDataSet *DataSet);
	void __fastcall DBGrid1DblClick(TObject *Sender);
	void __fastcall DBGrid1CellClick(TColumn *Column);
	void __fastcall ClickTimer1Timer(TObject *Sender);
	void __fastcall ByDateTimePickerChange(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall DBGrid1KeyPress(TObject *Sender, System::WideChar &Key);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall ClickTimer2Timer(TObject *Sender);
	void __fastcall DBGrid2CellClick(TColumn *Column);
	void __fastcall DBGrid2DblClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall DBGrid2KeyPress(TObject *Sender, System::WideChar &Key);
	void __fastcall RefreshTimerTimer(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
	int clickCounter;
	void editTruck(bool newRecord);
	void editSample(bool newRecord);
	void refresh();
public:		// User declarations
	__fastcall TTrucksForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTrucksForm *TrucksForm;
//---------------------------------------------------------------------------
#endif
