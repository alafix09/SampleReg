//---------------------------------------------------------------------------

#ifndef TruckEditFormUnitH
#define TruckEditFormUnitH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <FireDAC.Comp.Client.hpp>
#include <FireDAC.Comp.DataSet.hpp>
#include <FireDAC.DApt.hpp>
#include <FireDAC.DApt.Intf.hpp>
#include <FireDAC.DatS.hpp>
#include <FireDAC.Phys.Intf.hpp>
#include <FireDAC.Stan.Async.hpp>
#include <FireDAC.Stan.Error.hpp>
#include <FireDAC.Stan.Intf.hpp>
#include <FireDAC.Stan.Option.hpp>
#include <FireDAC.Stan.Param.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTruckEditForm : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TFDQuery *FDQuery;
	TDataSource *DataSource;
	TDBMemo *MemoDescript;
	TDBEdit *EditLPN;
	TButton *OKButton;
	TButton *CancelButton;
	TLabel *Label3;
	TDBLookupComboBox *CBMat;
	TDataSource *DataSourceMaterial;
	TFDQuery *FDQueryMaterial;
	TGroupBox *GroupBox1;
	TDBEdit *EditGlyuten;
	TLabel *Label8;
	TDBEdit *EditHumidity;
	TLabel *Label9;
	TDBEdit *EditNature;
	TLabel *Label10;
	TGroupBox *GroupBox2;
	TLabel *Label11;
	TLabel *Label12;
	TLabel *Label13;
	TDBEdit *EditPartCont;
	TDBEdit *EditWagState;
	TGroupBox *GroupBox3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TDBEdit *EditNumSpec;
	TDBEdit *EditNumNakl;
	TDBEdit *EditNumVet;
	TDBEdit *EditInn;
	TFDQuery *FDQueryId;
	TFDCommand *FDCommandId;
	TDBComboBox *DBComboBox1;
	void __fastcall OKButtonClick(TObject *Sender);
	void __fastcall CancelButtonClick(TObject *Sender);
	void __fastcall FDQueryAfterEdit(TDataSet *DataSet);
	void __fastcall FDQueryAfterApplyUpdates(TFDDataSet *DataSet, int AErrors);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall MemoDescriptKeyPress(TObject *Sender, System::WideChar &Key);
private:	// User declarations
	int id;
	bool changed;
    String initCaption;
public:		// User declarations
	__fastcall TTruckEditForm(TComponent* Owner);
	bool setId(int id);
	bool isChanged()
	{   return changed; }
	void setChanged(bool aChanged);
};
//---------------------------------------------------------------------------
extern PACKAGE TTruckEditForm *TruckEditForm;
//---------------------------------------------------------------------------
#endif
